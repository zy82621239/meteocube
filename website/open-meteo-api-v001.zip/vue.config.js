const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  devServer:{
    proxy: {
      '/v1': {
        target: 'https://api.open-meteo.com/',// 代理目标的基础路径
        
        // changeOrigin设置为true时，服务器收到的请求头中的host为http://11.111.11.111:5000
        // 设置为false时，服务器收到的请求头中的host为http://localhost:8080
        // 默认设置为true
        changeOrigin: true, 
      }
    }
  }
})
