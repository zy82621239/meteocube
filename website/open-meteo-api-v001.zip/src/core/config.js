var baseUrl = 'https://api.open-meteo.com/';
// if(process.env.NODE_ENV === 'production'){
// 	baseUrl = location.origin+'/';
// }

module.exports = {
    baseUrl,
    openMeteoConfig:{
        timezone:[
            "America/Anchorage",
            "America/Los_Angeles",
            "America/Denver",
            "America/Chicago",
            "America/New_York",
            "America/Sao_Paulo",
            {value:"UTC",name:"Not set (GMT+0)"},
            {value:"GMT",name:"GMT+0"},
            {value:"auto",name:"Automatically detect time zone"},
            "Europe/London",
            "Europe/Berlin",
            "Europe/Moscow",
            "Africa/Cairo",
            "Asia/Bangkok",
            "Asia/Singapore",
            "Asia/Tokyo",
            "Australia/Sydney",
            "Pacific/Auckland"
        ]
    }
}